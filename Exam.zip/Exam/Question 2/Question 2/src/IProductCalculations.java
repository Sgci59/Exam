public interface IProductCalculations {
    double getVat();
    double getCommision();
    double getTotal();
}
