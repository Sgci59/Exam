
import javax.swing.JOptionPane;

public class ProductSalesReport implements  IProductCalculations{

    void main() {
        String customerName, selectedItem;
        String[] products = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
        double itemPrice;

        int idx;

        customerName = JOptionPane.showInputDialog(null, "Customer Name: ");
        idx = Integer.parseInt(JOptionPane.showInputDialog(null, "Select Product: \n 1. Cozy Nights Monarch \n 2. Restonic Barbados \n 3. Sealy Phuket"));
        itemPrice = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter Price: "));

        JOptionPane.showMessageDialog(null, "Customer Name: " + customerName + "\nProduct: " + products[idx - 1] + "\nVAT: " + "\nCommission: " + "\nTotal: ");
    }




    @Override
    public double getVat() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public double getCommision() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public double getTotal() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
