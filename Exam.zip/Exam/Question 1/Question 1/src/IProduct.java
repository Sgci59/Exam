 interface IProduct {
    int getTotalProductSold();
    double getAverageProductSold();
    String getMostPopularProduct();
}
