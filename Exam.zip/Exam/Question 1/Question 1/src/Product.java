
import java.util.Scanner;

public class Product implements IProduct{
    //Declare 1D arrays.
    int[] cozyNightsMonarch = new int[3];
    int[] restonicBarbados = new int[3];
    int[] sealyPhuket = new int[3];
    int totalProductsSold, totalCNM, totalRB, totalSP;
    double averageProductsSold;
    String mostPopular;

    Scanner input = new Scanner(System.in);
    String[] products = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
    //This methods intends to capture product sales data 
    void enterSalesData(){

        for (int i = 0; i < cozyNightsMonarch.length; i++) {
            System.out.print("Enter number of sales for month " + (i + 1)+ " for " + products[0] + "mattress: ");
            cozyNightsMonarch[i] = input.nextInt();
        }
        System.out.println(" ");//space
        for (int j = 0; j < restonicBarbados.length; j++) {
            System.out.print("Enter number of sales for month " + (j + 1)+ " for " + products[1] + "mattress: ");
            restonicBarbados[j] = input.nextInt();
        }
        System.out.println(" ");//space
        for (int k = 0; k < sealyPhuket.length; k++) {
            System.out.print("Enter number of sales for month " + (k + 1)+ " for " + products[2] + "mattress: ");
            sealyPhuket[k] = input.nextInt();
        }
    }

    @Override
    public int getTotalProductSold() {
        //calculates total sales for Cozy Nights Monarch.
        for (int i = 0; i < cozyNightsMonarch.length; i++) {
            totalCNM += cozyNightsMonarch[i];
        }
        //calculates total sales for Restonic Barbados.
        for (int j = 0; j < restonicBarbados.length; j++) {
            totalCNM += restonicBarbados[j];
        }
        //calculates total sales for Sealy Phuket.
        for (int k = 0; k < sealyPhuket.length; k++) {
            totalCNM += sealyPhuket[k];
        }

        totalProductsSold = totalCNM + totalRB + totalSP;

        return totalProductsSold;
    }

    @Override
    public double getAverageProductSold() {
        int divider = sealyPhuket.length + restonicBarbados.length + cozyNightsMonarch.length;
        averageProductsSold = totalProductsSold / (divider );

        return averageProductsSold;
    }

    @Override
    public String getMostPopularProduct() {
        
        if(totalCNM > totalRB && totalCNM > totalSP){
            mostPopular = products[0];
        }
        else if (totalRB > totalCNM && totalRB > totalSP){
            mostPopular = products[1];
        }
        else {
            mostPopular = products[2];
        }        

        return mostPopular;
    }

    void main() {
        enterSalesData();
        getTotalProductSold();
        getAverageProductSold();
        getMostPopularProduct();
         System.out.println("");
         System.out.println("PRODUCT SALES REPORT - 2026");
         System.out.println("**************************************************");
         System.out.println("TOTAL PRODUCT SALES: " + totalProductsSold);
         System.out.println("AVERAGE PRODUCT SALES: " + averageProductsSold);
         System.out.println("MOST POPULAR PRODUCT: " + mostPopular);
        
    }
    
}
